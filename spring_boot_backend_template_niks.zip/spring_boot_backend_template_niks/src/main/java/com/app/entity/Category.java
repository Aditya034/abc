package com.app.entity;

public enum Category {

	 EXPRESS,
	 SHATABDI,
     AC,
     METRO
}
